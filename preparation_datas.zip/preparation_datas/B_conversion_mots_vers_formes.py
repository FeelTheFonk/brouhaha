import os

# Obtenez le chemin absolu du fichier en cours
current_path = os.path.abspath(__file__)
base_dir = os.path.dirname(current_path)
dictionary_path = os.path.join(base_dir, 'dictionnaire_formes.txt')
resultat_identification_path = os.path.join(base_dir, 'resultat_identification.txt')
resultat_conversion_path = os.path.join(base_dir, 'resultat_conversion.txt')
occurrence_path = os.path.join(base_dir, 'occurrence.txt')

def load_dictionary(filepath):
    print("Loading dictionary...")
    dictionary = {}
    with open(filepath, 'r', encoding='utf-8') as file:
        for line in file:
            expression, definition = line.strip().split('|')
            dictionary[expression.lower()] = definition
    print(f"Loaded {len(dictionary)} expressions.")
    return dictionary

def process_sentences(input_filepath, output_filepath, dictionary):
    print("Processing sentences...")
    occurrences = {}
    with open(input_filepath, 'r', encoding='utf-8') as file_in:
        with open(output_filepath, 'w', encoding='utf-8') as file_out:
            for line in file_in:
                sentence = []
                for expression in line.strip().split('|'):
                    if expression in dictionary:
                        sentence.append(dictionary[expression])
                        occurrences[expression] = occurrences.get(expression, 0) + 1
                file_out.write('|'.join(sentence) + '\n')
    print(f"Processed sentences. Written to {output_filepath}.")
    return occurrences

def write_occurrences(filepath, occurrences):
    print("Writing occurrences...")
    with open(filepath, 'w', encoding='utf-8') as file:
        for expression, count in occurrences.items():
            file.write(f"{expression}: {count}\n")
    print(f"Written occurrences to {filepath}.")

def main():
    dictionary = load_dictionary(dictionary_path)
    occurrences = process_sentences(resultat_identification_path, resultat_conversion_path, dictionary)
    write_occurrences(occurrence_path, occurrences)

if __name__ == "__main__":
    main()
