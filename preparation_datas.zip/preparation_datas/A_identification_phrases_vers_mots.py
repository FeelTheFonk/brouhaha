import string
import concurrent.futures

def load_expressions(filepath):
    print("Loading expressions...")
    with open(filepath, 'r', encoding='utf-8') as file:
        expressions = file.read().splitlines()
    # Convert to lowercase and sort expressions by length, in descending order
    expressions = [exp.lower() for exp in expressions]
    expressions.sort(key=len, reverse=True)
    print(f"Loaded {len(expressions)} expressions.")
    return expressions

def load_sentences(filepath):
    print("Loading sentences...")
    with open(filepath, 'r', encoding='utf-8') as file:
        sentences = file.read().splitlines()
    print(f"Loaded {len(sentences)} sentences.")
    return sentences

def find_expressions_in_sentence(sentence, expressions):
    sentence = sentence.lower()
    i = 0
    found = []
    while i < len(sentence):
        matched_expressions = []
        for expression in expressions:
            if sentence[i:i+len(expression)] == expression:
                matched_expressions.append(expression)
        if matched_expressions:
            # Choose the longest expression
            longest_expression = max(matched_expressions, key=len)
            found.append(longest_expression)
            i += len(longest_expression)
        else:
            i += 1
    return found if found else None

def main():
    expressions = load_expressions('dictionnaire.txt')
    sentences = load_sentences('phrases.txt')

    with open('resultat_identification.txt', 'w', encoding='utf-8') as file:
        with concurrent.futures.ProcessPoolExecutor() as executor:
            for i, found in enumerate(executor.map(find_expressions_in_sentence, sentences, [expressions]*len(sentences)), 1):
                if found is not None:
                    file.write('|'.join(found) + '\n')
                print(f"Processed {i} sentences.")

if __name__ == "__main__":
    main()